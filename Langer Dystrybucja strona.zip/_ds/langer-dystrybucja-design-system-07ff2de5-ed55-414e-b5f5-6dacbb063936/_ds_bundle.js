/* @ds-bundle: {"format":3,"namespace":"LangerDystrybucjaDesignSystem_07ff2d","components":[],"sourceHashes":{"ui_kits/admin/AdminShell.jsx":"9cf337069676","ui_kits/admin/Dashboard.jsx":"c478cf28cc15","ui_kits/admin/Import.jsx":"99785955b2ab","ui_kits/admin/Products.jsx":"4d6057d1332c","ui_kits/admin/Rules.jsx":"b49ef2f6423d","ui_kits/customer/AccountOrders.jsx":"dd44bc81b2f3","ui_kits/customer/CartView.jsx":"a77ae24f57a7","ui_kits/customer/Catalog.jsx":"bf70e49b6f6b","ui_kits/customer/Shared.jsx":"9ff95994d510","ui_kits/customer/data.jsx":"cf454d39e1fc"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.LangerDystrybucjaDesignSystem_07ff2d = window.LangerDystrybucjaDesignSystem_07ff2d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/admin/AdminShell.jsx
try { (() => {
// Admin shell — sidebar navigation + header
const ICONS_A = {
  dashboard: '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  products: '<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="M3.3 7 12 12l8.7-5"/><path d="M12 22V12"/>',
  orders: '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  customers: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  rules: '<path d="M3 6h18"/><path d="M7 12h10"/><path d="M11 18h6"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  trending: '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>'
};
function AIcon({
  d,
  size = 18,
  stroke = 1.5
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    dangerouslySetInnerHTML: {
      __html: d
    }
  });
}
function AdminShell({
  view,
  setView,
  children
}) {
  const nav = [{
    id: 'dashboard',
    label: 'Dashboard',
    icon: ICONS_A.dashboard
  }, {
    id: 'products',
    label: 'Produkty',
    icon: ICONS_A.products
  }, {
    id: 'import',
    label: 'Import',
    icon: ICONS_A.upload
  }, {
    id: 'orders',
    label: 'Zamówienia',
    icon: ICONS_A.orders
  }, {
    id: 'customers',
    label: 'Klienci',
    icon: ICONS_A.customers
  }, {
    id: 'rules',
    label: 'Reguły',
    icon: ICONS_A.rules
  }, {
    id: 'settings',
    label: 'Ustawienia',
    icon: ICONS_A.settings
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "app"
  }, /*#__PURE__*/React.createElement("header", {
    className: "header"
  }, /*#__PURE__*/React.createElement("a", {
    className: "lang-wordmark",
    href: "#",
    style: {
      textDecoration: 'none'
    }
  }, "LANGER", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--graphite-500)',
      letterSpacing: '0.18em',
      fontStyle: 'normal',
      fontWeight: 600,
      marginLeft: 6
    }
  }, "DYSTRYBUCJA")), /*#__PURE__*/React.createElement("span", {
    className: "caps",
    style: {
      padding: '2px 8px',
      background: 'var(--graphite-900)',
      color: '#FFF',
      borderRadius: 3,
      letterSpacing: '0.1em'
    }
  }, "Admin"), /*#__PURE__*/React.createElement("div", {
    className: "header-spacer"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: 280
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      color: 'var(--fg-3)',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: ICONS_A.search,
    size: 16
  })), /*#__PURE__*/React.createElement("input", {
    className: "inp",
    placeholder: "Szukaj produkt\xF3w, zam\xF3wie\u0144, klient\xF3w\u2026",
    style: {
      paddingLeft: 32,
      fontSize: 13
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "row row-gap-2",
    style: {
      paddingLeft: 12,
      borderLeft: '1px solid var(--border-1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 999,
      background: 'var(--amber-500)',
      color: 'var(--ink)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 12,
      fontWeight: 700
    }
  }, "JL"), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, "Jan Langer"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 11
    }
  }, "Superadmin")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    className: "sidebar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "side-section"
  }, "Panel"), nav.slice(0, 2).map(n => /*#__PURE__*/React.createElement("a", {
    key: n.id,
    href: "#",
    onClick: e => {
      e.preventDefault();
      setView(n.id);
    },
    className: `side-item ${view === n.id ? 'active' : ''}`
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: n.icon
  }), " ", n.label)), /*#__PURE__*/React.createElement("div", {
    className: "side-section"
  }, "Operacje"), nav.slice(2, 5).map(n => /*#__PURE__*/React.createElement("a", {
    key: n.id,
    href: "#",
    onClick: e => {
      e.preventDefault();
      setView(n.id);
    },
    className: `side-item ${view === n.id ? 'active' : ''}`
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: n.icon
  }), " ", n.label)), /*#__PURE__*/React.createElement("div", {
    className: "side-section"
  }, "Konfiguracja"), nav.slice(5).map(n => /*#__PURE__*/React.createElement("a", {
    key: n.id,
    href: "#",
    onClick: e => {
      e.preventDefault();
      setView(n.id);
    },
    className: `side-item ${view === n.id ? 'active' : ''}`
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: n.icon
  }), " ", n.label))), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      padding: '24px 32px',
      maxWidth: 'calc(100% - 240px)'
    }
  }, children)));
}
const fmtZlA = n => n.toLocaleString('pl-PL', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
}) + ' zł';
const fmtNumA = n => Math.round(n).toLocaleString('pl-PL');
Object.assign(window, {
  AdminShell,
  AIcon,
  ICONS_A,
  fmtZlA,
  fmtNumA
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/AdminShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/Dashboard.jsx
try { (() => {
// Admin dashboard
function KPI({
  label,
  value,
  sub,
  accent,
  icon
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, label), icon && /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--fg-3)'
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: icon,
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    className: "num",
    style: {
      fontSize: 30,
      fontWeight: 700,
      letterSpacing: '-0.02em',
      marginTop: 8,
      color: accent || 'var(--fg-1)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 12,
      marginTop: 2
    }
  }, sub));
}
function Dashboard() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h1", null, "Dashboard"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 13
    }
  }, "\u015Aroda, 23 kwietnia 2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(KPI, {
    label: "Zam\xF3wienia dzi\u015B",
    value: "14",
    sub: "+3 vs. wczoraj",
    icon: ICONS_A.orders
  }), /*#__PURE__*/React.createElement(KPI, {
    label: "Obr\xF3t dzi\u015B",
    value: "18 420 z\u0142",
    sub: "+12,4% m/m",
    accent: "var(--margin-good)",
    icon: ICONS_A.trending
  }), /*#__PURE__*/React.createElement(KPI, {
    label: "\u015Arednia mar\u017Ca",
    value: "19,8%",
    sub: "cel 20,0%",
    accent: "var(--margin-ok)"
  }), /*#__PURE__*/React.createElement(KPI, {
    label: "Obr\xF3t w miesi\u0105cu",
    value: "284 120 z\u0142",
    sub: "plan: 320 000 z\u0142"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr',
      gap: 20,
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      padding: '16px 20px',
      borderBottom: '1px solid var(--border-1)',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 16
    }
  }, "Ostatnie zam\xF3wienia"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "mute",
    style: {
      fontSize: 13
    }
  }, "Zobacz wszystkie \u2192")), /*#__PURE__*/React.createElement("table", {
    className: "t"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Numer"), /*#__PURE__*/React.createElement("th", null, "Klient"), /*#__PURE__*/React.createElement("th", null, "Czas"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Warto\u015B\u0107"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Mar\u017Ca"), /*#__PURE__*/React.createElement("th", null, "Status"))), /*#__PURE__*/React.createElement("tbody", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "num",
    style: {
      fontWeight: 600
    }
  }, "2026/00042"), /*#__PURE__*/React.createElement("td", null, "Budmax sp. z o.o. ", /*#__PURE__*/React.createElement("span", {
    className: "tier gold",
    style: {
      padding: '1px 6px',
      fontSize: 9,
      marginLeft: 6
    }
  }, "Z\u0142oto")), /*#__PURE__*/React.createElement("td", {
    className: "mute"
  }, "12 min temu"), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, "3 213,20 z\u0142"), /*#__PURE__*/React.createElement("td", {
    className: "num margin-good"
  }, "19,9%"), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "badge pending"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Oczekuje"))), /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "num",
    style: {
      fontWeight: 600
    }
  }, "2026/00041"), /*#__PURE__*/React.createElement("td", null, "Hurtownia Kowalski"), /*#__PURE__*/React.createElement("td", {
    className: "mute"
  }, "48 min temu"), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, "1 840,00 z\u0142"), /*#__PURE__*/React.createElement("td", {
    className: "num margin-ok"
  }, "17,6%"), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "badge confirmed"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Potwierdzone"))), /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "num",
    style: {
      fontWeight: 600
    }
  }, "2026/00040"), /*#__PURE__*/React.createElement("td", null, "Market Bud-Mat ", /*#__PURE__*/React.createElement("span", {
    className: "tier silver",
    style: {
      padding: '1px 6px',
      fontSize: 9,
      marginLeft: 6
    }
  }, "Srebro")), /*#__PURE__*/React.createElement("td", {
    className: "mute"
  }, "1 godz. temu"), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, "920,50 z\u0142"), /*#__PURE__*/React.createElement("td", {
    className: "num margin-bad"
  }, "14,2%"), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "badge confirmed"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Potwierdzone"))), /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "num",
    style: {
      fontWeight: 600
    }
  }, "2026/00039"), /*#__PURE__*/React.createElement("td", null, "Castor Sp.J."), /*#__PURE__*/React.createElement("td", {
    className: "mute"
  }, "2 godz. temu"), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, "4 820,00 z\u0142"), /*#__PURE__*/React.createElement("td", {
    className: "num margin-good"
  }, "20,8%"), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "badge shipped"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Wys\u0142ane"))), /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "num",
    style: {
      fontWeight: 600
    }
  }, "2026/00038"), /*#__PURE__*/React.createElement("td", null, "Sklep Budowlany Jurek"), /*#__PURE__*/React.createElement("td", {
    className: "mute"
  }, "4 godz. temu"), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, "680,40 z\u0142"), /*#__PURE__*/React.createElement("td", {
    className: "num margin-good"
  }, "22,1%"), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "badge delivered"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Dostarczone")))))), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 16,
      marginBottom: 12
    }
  }, "Alerty"), /*#__PURE__*/React.createElement("div", {
    className: "stack-3"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start',
      padding: 12,
      background: 'var(--margin-bad-bg)',
      borderRadius: 6,
      borderLeft: '3px solid var(--margin-bad)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--margin-bad)'
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: ICONS_A.alert,
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--margin-bad)'
    }
  }, "Mar\u017Ca poni\u017Cej progu"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-2)',
      marginTop: 2
    }
  }, "Zam\xF3wienie 2026/00040 \u2014 14,2%. Sprawd\u017A cennik."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start',
      padding: 12,
      background: 'var(--margin-ok-bg)',
      borderRadius: 6,
      borderLeft: '3px solid var(--margin-ok)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--margin-ok)'
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: ICONS_A.alert,
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--margin-ok)'
    }
  }, "Niski stan magazynu"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-2)',
      marginTop: 2
    }
  }, "Soudal Fix All 310 ml \u2014 48 szt. (poni\u017Cej 50)."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start',
      padding: 12,
      background: 'var(--margin-good-bg)',
      borderRadius: 6,
      borderLeft: '3px solid var(--margin-good)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--margin-good)'
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: ICONS_A.trending,
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--margin-good)'
    }
  }, "Awans tieru"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-2)',
      marginTop: 2
    }
  }, "Castor Sp.J. przekroczy\u0142 pr\xF3g Platyny.")))))));
}
Object.assign(window, {
  Dashboard,
  KPI
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/Import.jsx
try { (() => {
// Import flow — 3 steps: upload → preview → result
const {
  useState: useStateI
} = React;
function Import() {
  const [step, setStep] = useStateI(2); // land on preview, most interesting
  const [strategy, setStrategy] = useStateI('upsert');
  const previewRows = [['SOU-CL-750', 'Soudal Classic 750 ml', 'Soudal', 'Piany', 17.73, 20.99, 240, 'MAGNET', 'ok'], ['LAN-70-750', 'Langer 70 750 ml', 'Langer', 'Piany', 14.50, 19.99, 180, 'MARGIN', 'ok'], ['LAN-PRO-750', 'Langer Pro 750 ml', 'Langer', 'Piany', 15.20, 20.99, NaN, 'MARGIN', 'warn'], ['SOU-FA-310', 'Soudal Fix All 310 ml', 'Soudal', 'Kleje', 24.10, 28.40, 48, 'MAGNET', 'ok'], ['TYT-35-300', 'Tytan 35 300 ml', 'Tytan', 'Kleje', '', 18.00, 110, 'NEUTRAL', 'err'], ['LAN-SAN-280', 'Langer Sanitary 280 ml', 'Langer', 'Silikony', 7.20, 11.80, 210, 'MARGIN', 'ok']];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h1", null, "Import produkt\xF3w"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost"
  }, "\u2190 Wr\xF3\u0107 do produkt\xF3w")), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      gap: 0,
      marginBottom: 22
    }
  }, ['Plik', 'Podgląd', 'Gotowe'].map((label, i) => {
    const done = step > i + 1,
      active = step === i + 1;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "row",
      style: {
        flex: i < 2 ? 1 : 'none',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 28,
        height: 28,
        borderRadius: 999,
        background: active ? 'var(--graphite-900)' : done ? 'var(--margin-good)' : 'var(--graphite-100)',
        color: active || done ? '#FFF' : 'var(--fg-3)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 13,
        fontWeight: 600
      }
    }, done ? '✓' : i + 1), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: active ? 600 : 500,
        color: active || done ? 'var(--fg-1)' : 'var(--fg-3)'
      }
    }, label), i < 2 && /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 1,
        background: done ? 'var(--margin-good)' : 'var(--border-1)',
        marginLeft: 10
      }
    }));
  })), step === 1 && /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 40,
      textAlign: 'center',
      border: '2px dashed var(--border-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--fg-3)',
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: ICONS_A.upload,
    size: 32
  })), /*#__PURE__*/React.createElement("h2", {
    style: {
      marginTop: 12
    }
  }, "Przeci\u0105gnij plik lub kliknij, by wybra\u0107"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      marginTop: 6
    }
  }, "Obs\u0142ugiwane formaty: .xlsx, .csv \xB7 max 10 MB"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    style: {
      marginTop: 20
    },
    onClick: () => setStep(2)
  }, "Wybierz plik"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      marginTop: 14,
      fontSize: 12
    }
  }, "Wymagane kolumny: sku, name, purchase_price, sell_price")), step === 2 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: '14px 18px',
      marginBottom: 14,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row row-gap-4"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Plik"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "lang-mono"
  }, "katalog_04_2026.xlsx"), " ", /*#__PURE__*/React.createElement("span", {
    className: "mute"
  }, "(248 KB)"))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 32,
      background: 'var(--border-1)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Wierszy"), /*#__PURE__*/React.createElement("div", {
    className: "num",
    style: {
      fontSize: 14,
      fontWeight: 600,
      marginTop: 2
    }
  }, "127")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Do dodania"), /*#__PURE__*/React.createElement("div", {
    className: "num margin-good",
    style: {
      fontSize: 14,
      fontWeight: 600,
      marginTop: 2
    }
  }, "89")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Aktualizacje"), /*#__PURE__*/React.createElement("div", {
    className: "num",
    style: {
      fontSize: 14,
      fontWeight: 600,
      marginTop: 2
    }
  }, "35")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "B\u0142\u0119dy"), /*#__PURE__*/React.createElement("div", {
    className: "num margin-bad",
    style: {
      fontSize: 14,
      fontWeight: 600,
      marginTop: 2
    }
  }, "3")))), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 0,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px',
      borderBottom: '1px solid var(--border-1)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 15
    }
  }, "Podgl\u0105d \xB7 pierwsze 6 wierszy")), /*#__PURE__*/React.createElement("table", {
    className: "t",
    style: {
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "SKU"), /*#__PURE__*/React.createElement("th", null, "Nazwa"), /*#__PURE__*/React.createElement("th", null, "Marka"), /*#__PURE__*/React.createElement("th", null, "Kategoria"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Zakup"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Sprzeda\u017C"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Stan"), /*#__PURE__*/React.createElement("th", null, "Rola"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 80
    }
  }, "Walidacja"))), /*#__PURE__*/React.createElement("tbody", null, previewRows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      background: r[8] === 'err' ? 'var(--margin-bad-bg)' : r[8] === 'warn' ? 'var(--margin-ok-bg)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement("td", {
    className: "sku"
  }, r[0]), /*#__PURE__*/React.createElement("td", null, r[1]), /*#__PURE__*/React.createElement("td", null, r[2]), /*#__PURE__*/React.createElement("td", null, r[3]), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, r[4] === '' ? /*#__PURE__*/React.createElement("span", {
    className: "margin-bad"
  }, "\u2014") : fmtZlA(r[4])), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, fmtZlA(r[5])), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, isNaN(r[6]) ? /*#__PURE__*/React.createElement("span", {
    className: "margin-ok"
  }, "brak") : r[6]), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(RoleTag, {
    role: r[7]
  })), /*#__PURE__*/React.createElement("td", null, r[8] === 'ok' && /*#__PURE__*/React.createElement("span", {
    className: "badge delivered"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "OK"), r[8] === 'warn' && /*#__PURE__*/React.createElement("span", {
    className: "badge shipped"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Ostrz."), r[8] === 'err' && /*#__PURE__*/React.createElement("span", {
    className: "badge cancelled"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "B\u0142\u0105d"))))))), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 15,
      marginBottom: 12
    }
  }, "Strategia importu"), /*#__PURE__*/React.createElement("div", {
    className: "stack-2"
  }, [{
    v: 'upsert',
    t: 'Dodaj nowe + aktualizuj istniejące (po SKU)',
    sub: 'Zalecane. Bezpieczne dla bieżącego katalogu.'
  }, {
    v: 'new',
    t: 'Tylko nowe produkty',
    sub: 'Pominie SKU, które już istnieją.'
  }, {
    v: 'replace',
    t: 'Nadpisz wszystko',
    sub: '⚠ Usunie wszystkie obecne produkty spoza pliku.'
  }].map(o => /*#__PURE__*/React.createElement("label", {
    key: o.v,
    style: {
      display: 'flex',
      gap: 12,
      padding: 12,
      border: '1px solid var(--border-1)',
      borderRadius: 6,
      cursor: 'pointer',
      background: strategy === o.v ? 'var(--amber-50)' : 'var(--white)',
      borderColor: strategy === o.v ? 'var(--amber-500)' : 'var(--border-1)'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: "strat",
    checked: strategy === o.v,
    onChange: () => setStrategy(o.v),
    style: {
      accentColor: 'var(--ink)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600
    }
  }, o.t), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 12
    }
  }, o.sub))))), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      gap: 10,
      marginTop: 18,
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => setStep(1)
  }, "Anuluj"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => setStep(3)
  }, "Importuj 127 wierszy")))), step === 3 && /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 40,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 999,
      background: 'var(--margin-good-bg)',
      color: 'var(--margin-good)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 24,
      fontWeight: 700
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("h2", {
    style: {
      marginTop: 14,
      fontSize: 22
    }
  }, "Import zako\u0144czony"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      marginTop: 6
    }
  }, "Zaimportowano 124 z 127 wierszy."), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'center',
      gap: 32,
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Dodane"), /*#__PURE__*/React.createElement("div", {
    className: "num margin-good",
    style: {
      fontSize: 24,
      fontWeight: 700,
      marginTop: 4
    }
  }, "89")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Zaktualizowane"), /*#__PURE__*/React.createElement("div", {
    className: "num",
    style: {
      fontSize: 24,
      fontWeight: 700,
      marginTop: 4
    }
  }, "35")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "B\u0142\u0119dy"), /*#__PURE__*/React.createElement("div", {
    className: "num margin-bad",
    style: {
      fontSize: 24,
      fontWeight: 700,
      marginTop: 4
    }
  }, "3"))), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      gap: 10,
      justifyContent: 'center',
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary"
  }, "Pobierz raport"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => setStep(1)
  }, "Nowy import"))));
}
Object.assign(window, {
  Import
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/Import.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/Products.jsx
try { (() => {
// Products table (admin view — shows role, cost, margin)
const ADMIN_PRODUCTS = [{
  sku: 'SOU-CL-750',
  name: 'Soudal Classic 750 ml',
  brand: 'Soudal',
  category: 'Piany',
  role: 'MAGNET',
  purchase: 17.73,
  sell: 20.99,
  stock: 240
}, {
  sku: 'LAN-70-750',
  name: 'Langer 70 750 ml',
  brand: 'Langer',
  category: 'Piany',
  role: 'MARGIN',
  purchase: 14.50,
  sell: 19.99,
  stock: 180
}, {
  sku: 'TYT-O2-750',
  name: 'Tytan O2 750 ml',
  brand: 'Tytan',
  category: 'Piany',
  role: 'NEUTRAL',
  purchase: 18.00,
  sell: 22.50,
  stock: 96
}, {
  sku: 'PEN-GOLD-750',
  name: 'Penosil Gold 750 ml',
  brand: 'Penosil',
  category: 'Piany',
  role: 'NEUTRAL',
  purchase: 17.20,
  sell: 21.80,
  stock: 72
}, {
  sku: 'SOU-SIL-280',
  name: 'Soudal Silirub 2 280 ml',
  brand: 'Soudal',
  category: 'Silikony',
  role: 'MAGNET',
  purchase: 12.80,
  sell: 14.50,
  stock: 312
}, {
  sku: 'LAN-SAN-280',
  name: 'Langer Sanitary 280 ml',
  brand: 'Langer',
  category: 'Silikony',
  role: 'MARGIN',
  purchase: 7.20,
  sell: 11.80,
  stock: 210
}, {
  sku: 'LAN-AKR-300',
  name: 'Langer Akryl 300 ml',
  brand: 'Langer',
  category: 'Akryle',
  role: 'MARGIN',
  purchase: 3.90,
  sell: 6.80,
  stock: 420
}, {
  sku: 'SOU-FA-310',
  name: 'Soudal Fix All 310 ml',
  brand: 'Soudal',
  category: 'Kleje',
  role: 'MAGNET',
  purchase: 24.10,
  sell: 28.40,
  stock: 48
}, {
  sku: 'LAN-MS-290',
  name: 'Langer MS Poly 290 ml',
  brand: 'Langer',
  category: 'Kleje',
  role: 'MARGIN',
  purchase: 14.80,
  sell: 22.90,
  stock: 120
}, {
  sku: 'LAN-PIS-PRO',
  name: 'Pistolet Langer Pro',
  brand: 'Langer',
  category: 'Akcesoria',
  role: 'PREMIUM',
  purchase: 62.00,
  sell: 120.00,
  stock: 36
}];
function RoleTag({
  role
}) {
  const map = {
    MAGNET: {
      cls: 'magnet',
      label: 'Magnes'
    },
    MARGIN: {
      cls: 'margin',
      label: 'Marżowiec'
    },
    NEUTRAL: {
      cls: 'neutral',
      label: 'Neutralny'
    },
    PREMIUM: {
      cls: 'premium',
      label: 'Premium'
    }
  };
  const r = map[role];
  return /*#__PURE__*/React.createElement("span", {
    className: `role ${r.cls}`
  }, r.label);
}
function Products() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, "Produkty"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 13,
      marginTop: 4
    }
  }, ADMIN_PRODUCTS.length, " pozycji w katalogu")), /*#__PURE__*/React.createElement("div", {
    className: "row row-gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary"
  }, /*#__PURE__*/React.createElement(AIcon, {
    d: ICONS_A.upload,
    size: 14
  }), " Import"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary"
  }, "+ Nowy produkt"))), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      padding: '14px 20px',
      borderBottom: '1px solid var(--border-1)',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "inp",
    placeholder: "Szukaj po SKU lub nazwie\u2026",
    style: {
      maxWidth: 320,
      fontSize: 13
    }
  }), /*#__PURE__*/React.createElement("select", {
    className: "inp",
    style: {
      maxWidth: 160,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("option", null, "Wszystkie kategorie")), /*#__PURE__*/React.createElement("select", {
    className: "inp",
    style: {
      maxWidth: 160,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("option", null, "Wszystkie role")), /*#__PURE__*/React.createElement("div", {
    className: "flex-1"
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost btn-sm"
  }, "Eksportuj CSV")), /*#__PURE__*/React.createElement("table", {
    className: "t"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "SKU"), /*#__PURE__*/React.createElement("th", null, "Produkt"), /*#__PURE__*/React.createElement("th", null, "Kategoria"), /*#__PURE__*/React.createElement("th", null, "Rola"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Zakup"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Sprzeda\u017C"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Mar\u017Ca"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Stan"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 40
    }
  }))), /*#__PURE__*/React.createElement("tbody", null, ADMIN_PRODUCTS.map(p => {
    const margin = (p.sell - p.purchase) / p.sell * 100;
    const mCls = margin >= 20 ? 'margin-good' : margin >= 15 ? 'margin-ok' : 'margin-bad';
    return /*#__PURE__*/React.createElement("tr", {
      key: p.sku
    }, /*#__PURE__*/React.createElement("td", {
      className: "sku"
    }, p.sku), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600
      }
    }, p.name), /*#__PURE__*/React.createElement("div", {
      className: "mute",
      style: {
        fontSize: 11
      }
    }, p.brand)), /*#__PURE__*/React.createElement("td", null, p.category), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(RoleTag, {
      role: p.role
    })), /*#__PURE__*/React.createElement("td", {
      className: "num"
    }, fmtZlA(p.purchase)), /*#__PURE__*/React.createElement("td", {
      className: "num",
      style: {
        fontWeight: 600
      }
    }, fmtZlA(p.sell)), /*#__PURE__*/React.createElement("td", {
      className: `num ${mCls}`,
      style: {
        fontWeight: 600
      }
    }, margin.toFixed(1).replace('.', ','), "%"), /*#__PURE__*/React.createElement("td", {
      className: `num ${p.stock < 50 ? 'margin-ok' : ''}`
    }, p.stock), /*#__PURE__*/React.createElement("td", {
      style: {
        color: 'var(--fg-3)',
        textAlign: 'center'
      }
    }, "\u22EE"));
  })))));
}
Object.assign(window, {
  Products,
  RoleTag
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/Products.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/Rules.jsx
try { (() => {
// Match rules editor
function Rules() {
  const rules = [{
    id: 1,
    name: 'Soudal Classic → Langer 70',
    trigger: 'SOU-CL-750 (produkt)',
    suggest: 'LAN-70-750 (produkt)',
    prio: 10,
    active: true
  }, {
    id: 2,
    name: 'Piany (magnet) → Langer Akryl',
    trigger: 'Piany (kategoria)',
    suggest: 'LAN-AKR-300 (produkt)',
    prio: 5,
    active: true
  }, {
    id: 3,
    name: 'Silikony → Langer Sanitary',
    trigger: 'Silikony (kategoria)',
    suggest: 'LAN-SAN-280 (produkt)',
    prio: 7,
    active: true
  }, {
    id: 4,
    name: 'Soudal Fix All → Langer MS Poly',
    trigger: 'SOU-FA-310 (produkt)',
    suggest: 'LAN-MS-290 (produkt)',
    prio: 9,
    active: true
  }, {
    id: 5,
    name: 'Piany → Akcesoria (pistolety)',
    trigger: 'Piany (kategoria)',
    suggest: 'Akcesoria (kategoria)',
    prio: 3,
    active: false
  }, {
    id: 6,
    name: 'Tytan O2 → Langer 70',
    trigger: 'TYT-O2-750 (produkt)',
    suggest: 'LAN-70-750 (produkt)',
    prio: 6,
    active: true
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, "Regu\u0142y matchowania"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 13,
      marginTop: 4
    }
  }, "Okre\u015Blaj\u0105, co system podpowiada klientowi przy produktach-magnesach.")), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary"
  }, "+ Nowa regu\u0142a")), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "t"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Nazwa"), /*#__PURE__*/React.createElement("th", null, "Trigger"), /*#__PURE__*/React.createElement("th", null), /*#__PURE__*/React.createElement("th", null, "Sugestia"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Priorytet"), /*#__PURE__*/React.createElement("th", null, "Aktywna"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 60
    }
  }))), /*#__PURE__*/React.createElement("tbody", null, rules.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.id,
    style: {
      opacity: r.active ? 1 : 0.5
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      fontWeight: 600
    }
  }, r.name), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "sku",
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12
    }
  }, r.trigger)), /*#__PURE__*/React.createElement("td", {
    style: {
      color: 'var(--fg-3)'
    }
  }, "\u2192"), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "sku",
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12
    }
  }, r.suggest)), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, r.prio), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-block',
      width: 34,
      height: 20,
      borderRadius: 999,
      background: r.active ? 'var(--amber-500)' : 'var(--graphite-200)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: r.active ? 16 : 2,
      width: 16,
      height: 16,
      borderRadius: 999,
      background: '#FFF',
      transition: 'left 120ms'
    }
  })))), /*#__PURE__*/React.createElement("td", {
    style: {
      color: 'var(--fg-3)',
      textAlign: 'center'
    }
  }, "\u22EE")))))));
}
Object.assign(window, {
  Rules
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/Rules.jsx", error: String((e && e.message) || e) }); }

// ui_kits/customer/AccountOrders.jsx
try { (() => {
// Account + orders views
function OrdersView() {
  const statusMap = {
    PENDING: {
      label: 'Oczekuje',
      cls: 'pending'
    },
    CONFIRMED: {
      label: 'Potwierdzone',
      cls: 'confirmed'
    },
    SHIPPED: {
      label: 'Wysłane',
      cls: 'shipped'
    },
    DELIVERED: {
      label: 'Dostarczone',
      cls: 'delivered'
    },
    CANCELLED: {
      label: 'Anulowane',
      cls: 'cancelled'
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '24px 32px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 28,
      marginBottom: 18
    }
  }, "Moje zam\xF3wienia"), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "t"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Numer"), /*#__PURE__*/React.createElement("th", null, "Data"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Pozycji"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Warto\u015B\u0107"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 160
    }
  }))), /*#__PURE__*/React.createElement("tbody", null, ORDERS_SEED.map(o => {
    const s = statusMap[o.status];
    return /*#__PURE__*/React.createElement("tr", {
      key: o.id
    }, /*#__PURE__*/React.createElement("td", {
      className: "num",
      style: {
        fontWeight: 600
      }
    }, o.number), /*#__PURE__*/React.createElement("td", null, o.date), /*#__PURE__*/React.createElement("td", {
      className: "num"
    }, o.items), /*#__PURE__*/React.createElement("td", {
      className: "num",
      style: {
        fontWeight: 600
      }
    }, fmtZl(o.total)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: `badge ${s.cls}`
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), s.label)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("button", {
      className: "btn btn-ghost btn-sm"
    }, "Zam\xF3w ponownie")));
  })))));
}
function AccountView() {
  const nextThreshold = 150000;
  const currentTurnover = CUSTOMER.yearlyTurnover;
  const toNext = nextThreshold * 2 - currentTurnover; // to Platinum
  const progress = Math.min(100, currentTurnover / (nextThreshold * 2) * 100);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1080,
      margin: '0 auto',
      padding: '24px 32px',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      gridColumn: '1/-1',
      fontSize: 28,
      marginBottom: 0
    }
  }, "Konto"), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Dane firmy"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 600,
      marginTop: 8
    }
  }, CUSTOMER.companyName), /*#__PURE__*/React.createElement("div", {
    className: "stack-2",
    style: {
      marginTop: 18,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sub"
  }, "NIP"), /*#__PURE__*/React.createElement("span", {
    className: "num"
  }, CUSTOMER.nip)), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sub"
  }, "Email"), /*#__PURE__*/React.createElement("span", null, "kontakt@budmax.pl")), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sub"
  }, "Osoba kontaktowa"), /*#__PURE__*/React.createElement("span", null, "Marcin Bieniek")), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sub"
  }, "Adres dostawy"), /*#__PURE__*/React.createElement("span", null, "ul. Hutnicza 12, 40-241 Katowice"))), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-sm",
    style: {
      marginTop: 16
    }
  }, "Edytuj dane")), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      background: 'var(--graphite-900)',
      color: '#FFF',
      border: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "caps",
    style: {
      color: 'var(--amber-500)'
    }
  }, "Tw\xF3j tier"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 12,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 36,
      fontWeight: 700,
      letterSpacing: '-0.02em'
    }
  }, "Z\u0142oto"), /*#__PURE__*/React.createElement("div", {
    className: "num",
    style: {
      color: '#C89B2E',
      fontSize: 16,
      fontWeight: 600
    }
  }, "\u22122% na wszystko")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      fontSize: 12,
      color: 'var(--graphite-300)',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("span", null, "Obr\xF3t 12 mies."), /*#__PURE__*/React.createElement("span", {
    className: "num"
  }, fmtZl(currentTurnover))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8,
      background: '#3A3F47',
      borderRadius: 999,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${progress}%`,
      height: '100%',
      background: 'var(--amber-500)',
      borderRadius: 999
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      marginTop: 10,
      color: 'var(--graphite-300)'
    }
  }, "Zam\xF3w jeszcze za ", /*#__PURE__*/React.createElement("strong", {
    className: "num",
    style: {
      color: '#FFF'
    }
  }, fmtZl(toNext)), ", aby awansowa\u0107 na ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: '#FFF'
    }
  }, "Platyn\u0119"), " (\u22123%)."))), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      gridColumn: '1/-1'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "caps",
    style: {
      marginBottom: 14
    }
  }, "Obr\xF3t miesi\u0119czny \xB7 ostatnie 6 mies."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 18,
      height: 140
    }
  }, [9200, 12400, 18200, 16800, 22300, 24600].map((v, i) => {
    const months = ['Lis', 'Gru', 'Sty', 'Lut', 'Mar', 'Kwi'];
    const maxV = 25000;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "num mute",
      style: {
        fontSize: 10
      }
    }, fmtNum(v)), /*#__PURE__*/React.createElement("div", {
      style: {
        width: '100%',
        height: `${v / maxV * 100}%`,
        background: i === 5 ? 'var(--amber-500)' : 'var(--graphite-200)',
        borderRadius: '4px 4px 0 0'
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "mute",
      style: {
        fontSize: 11
      }
    }, months[i]));
  }))));
}
Object.assign(window, {
  OrdersView,
  AccountView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/customer/AccountOrders.jsx", error: String((e && e.message) || e) }); }

// ui_kits/customer/CartView.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Cart view with live margin gauge + suggestion cards
const {
  useMemo: useMemoC
} = React;

// Pricing engine (simplified inline version of the spec's logic)
function calcMargin(items) {
  const revenue = items.reduce((s, i) => s + (i.finalPrice ?? i.sellPrice) * i.qty * i.unitsPerPackage, 0);
  const cost = items.reduce((s, i) => s + i.purchasePrice * i.qty * i.unitsPerPackage, 0);
  const marginAmount = revenue - cost;
  const marginPercent = revenue > 0 ? marginAmount / revenue * 100 : 0;
  return {
    revenue,
    cost,
    marginAmount,
    marginPercent
  };
}
function MarginGauge({
  percent
}) {
  const min = SETTINGS.minMargin,
    target = SETTINGS.targetMargin,
    max = 30;
  const state = percent < min ? 'bad' : percent < target ? 'ok' : 'good';
  const color = state === 'good' ? 'var(--margin-good)' : state === 'ok' ? 'var(--margin-ok)' : 'var(--margin-bad)';
  const pct = Math.max(0, Math.min(100, percent / max * 100));
  const minPct = min / max * 100,
    targetPct = target / max * 100;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, "Mar\u017Ca koszyka"), /*#__PURE__*/React.createElement("div", {
    className: "num",
    style: {
      fontSize: 30,
      fontWeight: 600,
      color,
      letterSpacing: '-0.01em',
      transition: 'color 180ms'
    }
  }, percent.toFixed(1).replace('.', ','), "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 10,
      background: 'var(--graphite-100)',
      borderRadius: 999
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      width: `${pct}%`,
      background: color,
      borderRadius: 999,
      transition: 'width 240ms cubic-bezier(0.2,0,0,1)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `${minPct}%`,
      top: -3,
      bottom: -3,
      width: 2,
      background: 'var(--graphite-700)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `${targetPct}%`,
      top: -3,
      bottom: -3,
      width: 2,
      background: 'var(--ink)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      marginTop: 6,
      fontSize: 10,
      color: 'var(--fg-3)',
      fontFamily: 'var(--font-mono)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "0%"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: `calc(32px + ${minPct}% - 20px)`
    }
  }, "min ", min, "%"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: `calc(32px + ${targetPct}% + 4px)`
    }
  }, "cel ", target, "%"), /*#__PURE__*/React.createElement("span", null, max, "%")));
}
function SuggestionCard({
  suggest,
  magnet,
  qty,
  saving,
  newPrice,
  oldPrice,
  onAdd
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--white)',
      border: '1px solid var(--amber-200)',
      borderLeft: '4px solid var(--amber-500)',
      borderRadius: 6,
      padding: '14px 16px',
      boxShadow: '0 1px 2px rgb(28 31 36 / 0.06)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      lineHeight: 1
    }
  }, "\uD83D\uDCA1"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.5
    }
  }, "Dobierz ", /*#__PURE__*/React.createElement("strong", null, qty, " ", qty === 1 ? 'karton' : 'kartony'), " ", /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'var(--amber-50)',
      padding: '0 4px',
      borderRadius: 3
    }
  }, suggest.name), " \u2014 ", /*#__PURE__*/React.createElement("strong", null, magnet.name.split(' ').slice(0, 2).join(' ')), " spadnie z ", /*#__PURE__*/React.createElement("span", {
    className: "num mute",
    style: {
      textDecoration: 'line-through'
    }
  }, fmtZl(oldPrice)), " na ", /*#__PURE__*/React.createElement("span", {
    className: "num margin-good",
    style: {
      fontWeight: 600
    }
  }, fmtZl(newPrice)), "."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--fg-2)',
      marginTop: 5
    }
  }, "Zyskujesz ", /*#__PURE__*/React.createElement("strong", {
    className: "num margin-good"
  }, fmtZl(saving)), " na ca\u0142ym zam\xF3wieniu."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-dark btn-sm",
    onClick: onAdd
  }, /*#__PURE__*/React.createElement(Icon, {
    d: ICONS.plus,
    size: 12
  }), " Dodaj do koszyka"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost btn-sm"
  }, "Zobacz produkt")))));
}

// Generate mock suggestions based on cart contents
function generateSuggestions(cart) {
  const magnets = cart.filter(c => c.role === 'MAGNET');
  if (!magnets.length) return [];
  const margins = PRODUCTS.filter(p => p.role === 'MARGIN' && !cart.some(c => c.id === p.id));
  const out = [];
  for (const m of magnets.slice(0, 2)) {
    for (const s of margins.slice(0, 2)) {
      const qty = 2;
      // Approximate: add 2 cartons of margin, simulate margin boost that allows discount
      const simCart = [...cart, {
        ...s,
        qty
      }];
      const {
        marginPercent: newMargin
      } = calcMargin(simCart);
      if (newMargin > SETTINGS.minMargin + 1) {
        // Offer discount on magnet so cart still >= min
        const discount = Math.min(SETTINGS.maxDiscount / 100, (newMargin - SETTINGS.minMargin) / 100 * 0.4);
        const newPrice = m.sellPrice * (1 - discount);
        const saving = (m.sellPrice - newPrice) * m.qty * m.unitsPerPackage;
        if (saving > 1) out.push({
          magnet: m,
          suggest: s,
          qty,
          newPrice,
          oldPrice: m.sellPrice,
          saving
        });
      }
    }
  }
  return out.sort((a, b) => b.saving - a.saving).slice(0, 3);
}
function CartView({
  cart,
  setCart
}) {
  const margin = useMemoC(() => calcMargin(cart), [cart]);
  const suggestions = useMemoC(() => generateSuggestions(cart), [cart]);
  const tierDiscount = margin.revenue * CUSTOMER.tierDiscount / 100;
  const finalTotal = margin.revenue - tierDiscount;
  const updateQty = (id, delta) => {
    setCart(c => c.map(i => i.id === id ? {
      ...i,
      qty: Math.max(1, i.qty + delta)
    } : i));
  };
  const remove = id => setCart(c => c.filter(i => i.id !== id));
  const addSuggested = s => {
    setCart(c => {
      const exists = c.find(i => i.id === s.suggest.id);
      if (exists) return c.map(i => i.id === s.suggest.id ? {
        ...i,
        qty: i.qty + s.qty
      } : i);
      return [...c, {
        ...s.suggest,
        qty: s.qty
      }];
    });
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '24px 32px',
      display: 'grid',
      gridTemplateColumns: '1fr 340px',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 28,
      marginBottom: 18
    }
  }, "Koszyk ", /*#__PURE__*/React.createElement("span", {
    className: "mute",
    style: {
      fontWeight: 400,
      fontSize: 18
    }
  }, "\xB7 ", cart.length, " ", cart.length === 1 ? 'pozycja' : 'pozycji')), cart.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      textAlign: 'center',
      padding: 64,
      color: 'var(--fg-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 600
    }
  }, "Koszyk jest pusty"), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      marginTop: 4,
      fontSize: 14
    }
  }, "Dodaj produkty z katalogu, aby zobaczy\u0107 podpowiedzi.")) : /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "t"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: 60
    }
  }), /*#__PURE__*/React.createElement("th", null, "Produkt"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Cena / szt."), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'center'
    }
  }, "Ilo\u015B\u0107 kart."), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "Warto\u015B\u0107"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 40
    }
  }))), /*#__PURE__*/React.createElement("tbody", null, cart.map(item => {
    const line = item.sellPrice * item.qty * item.unitsPerPackage;
    return /*#__PURE__*/React.createElement("tr", {
      key: item.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 44,
        height: 44,
        borderRadius: 5,
        background: `linear-gradient(135deg, ${item.tone}, #EEEDE8)`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: CATEGORY_ICON[item.category],
      style: {
        width: 24,
        height: 24,
        opacity: 0.7
      }
    }))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: 14
      }
    }, item.name), /*#__PURE__*/React.createElement("div", {
      className: "sku",
      style: {
        fontSize: 12,
        color: 'var(--fg-3)',
        fontFamily: 'var(--font-mono)'
      }
    }, item.sku, " \xB7 ", item.brand)), /*#__PURE__*/React.createElement("td", {
      className: "num"
    }, fmtZl(item.sellPrice)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "row",
      style: {
        justifyContent: 'center',
        gap: 2
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn btn-secondary btn-sm",
      style: {
        padding: '4px 8px',
        minWidth: 28
      },
      onClick: () => updateQty(item.id, -1)
    }, /*#__PURE__*/React.createElement(Icon, {
      d: ICONS.minus,
      size: 12
    })), /*#__PURE__*/React.createElement("div", {
      className: "num",
      style: {
        width: 44,
        textAlign: 'center',
        fontWeight: 600
      }
    }, item.qty), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-secondary btn-sm",
      style: {
        padding: '4px 8px',
        minWidth: 28
      },
      onClick: () => updateQty(item.id, 1)
    }, /*#__PURE__*/React.createElement(Icon, {
      d: ICONS.plus,
      size: 12
    }))), /*#__PURE__*/React.createElement("div", {
      className: "mute",
      style: {
        textAlign: 'center',
        fontSize: 10,
        marginTop: 3
      }
    }, item.qty * item.unitsPerPackage, " szt.")), /*#__PURE__*/React.createElement("td", {
      className: "num",
      style: {
        fontWeight: 600
      }
    }, fmtZl(line)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("button", {
      className: "btn btn-ghost btn-sm",
      style: {
        padding: 6,
        color: 'var(--fg-3)'
      },
      onClick: () => remove(item.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      d: ICONS.trash,
      size: 16
    }))));
  })))), suggestions.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      gap: 8,
      marginBottom: 12,
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 18
    }
  }, "Dobierz i zaoszcz\u0119d\u017A"), /*#__PURE__*/React.createElement("span", {
    className: "mute",
    style: {
      fontSize: 13
    }
  }, "\xB7 ", suggestions.length, " ", suggestions.length === 1 ? 'podpowiedź' : 'podpowiedzi')), /*#__PURE__*/React.createElement("div", {
    className: "stack-3"
  }, suggestions.map((s, i) => /*#__PURE__*/React.createElement(SuggestionCard, _extends({
    key: i
  }, s, {
    onAdd: () => addSuggested(s)
  })))))), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'sticky',
      top: 80,
      alignSelf: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 20
    }
  }, /*#__PURE__*/React.createElement(MarginGauge, {
    percent: margin.marginPercent
  }), /*#__PURE__*/React.createElement("div", {
    className: "divider",
    style: {
      margin: '20px 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "stack-2",
    style: {
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sub"
  }, "Warto\u015B\u0107 netto"), /*#__PURE__*/React.createElement("span", {
    className: "num"
  }, fmtZl(margin.revenue))), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sub"
  }, "Rabat tier ", /*#__PURE__*/React.createElement("span", {
    className: "tier gold",
    style: {
      padding: '1px 6px',
      fontSize: 9,
      marginLeft: 4
    }
  }, "Z\u0142oto \u22122%")), /*#__PURE__*/React.createElement("span", {
    className: "num margin-good"
  }, "\u2212", fmtZl(tierDiscount)))), /*#__PURE__*/React.createElement("div", {
    className: "divider",
    style: {
      margin: '14px 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "row",
    style: {
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, "Do zap\u0142aty netto"), /*#__PURE__*/React.createElement("span", {
    className: "num",
    style: {
      fontSize: 22,
      fontWeight: 700
    }
  }, fmtZl(finalTotal))), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 11,
      textAlign: 'right',
      marginTop: 2
    }
  }, "+ VAT 23% = ", fmtZl(finalTotal * 1.23)), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary btn-lg",
    style: {
      width: '100%',
      marginTop: 18,
      justifyContent: 'center'
    }
  }, "Z\u0142\xF3\u017C zam\xF3wienie ", /*#__PURE__*/React.createElement(Icon, {
    d: ICONS.arrowRight,
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 11,
      textAlign: 'center',
      marginTop: 8
    }
  }, "P\u0142atno\u015B\u0107 na faktur\u0119 \xB7 termin 14 dni"))));
}
Object.assign(window, {
  CartView,
  MarginGauge,
  SuggestionCard,
  calcMargin,
  generateSuggestions
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/customer/CartView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/customer/Catalog.jsx
try { (() => {
// Product card + product catalog view
const {
  useState: useStateP,
  useMemo: useMemoP
} = React;
const __noop_p = null;
function CatPlaceholder({
  product,
  size = 80
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4/3',
      background: `linear-gradient(135deg, ${product.tone} 0%, ${product.featured ? '#F6D98B' : '#EEEDE8'} 100%)`,
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: CATEGORY_ICON[product.category],
    style: {
      width: size * 0.65,
      height: size * 0.65,
      opacity: 0.72
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 8,
      left: 8,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)',
      background: 'rgba(255,255,255,0.85)',
      padding: '2px 6px',
      borderRadius: 3
    }
  }, product.sku), product.featured && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 8,
      right: 8,
      fontSize: 9,
      fontWeight: 700,
      color: 'var(--ink)',
      background: 'var(--amber-500)',
      padding: '2px 6px',
      borderRadius: 3,
      letterSpacing: '0.05em'
    }
  }, "POLECANE"));
}
function ProductCard({
  product,
  onAdd,
  inCart
}) {
  const effectivePrice = product.sellPrice * (1 - CUSTOMER.tierDiscount / 100);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--white)',
      border: '1px solid var(--border-1)',
      borderRadius: 8,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      transition: 'box-shadow 120ms',
      cursor: 'default'
    },
    onMouseEnter: e => e.currentTarget.style.boxShadow = '0 1px 2px rgb(28 31 36 / 0.08)',
    onMouseLeave: e => e.currentTarget.style.boxShadow = 'none'
  }, /*#__PURE__*/React.createElement(CatPlaceholder, {
    product: product
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px 14px',
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "caps"
  }, product.brand, " \xB7 ", product.category), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      lineHeight: 1.3,
      marginTop: 2
    }
  }, product.name), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "num",
    style: {
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: '-0.01em'
    }
  }, fmtZl(effectivePrice)), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 11
    }
  }, "za szt. \xB7 netto")), product.sellPrice !== effectivePrice && /*#__PURE__*/React.createElement("div", {
    className: "num mute",
    style: {
      fontSize: 11,
      textDecoration: 'line-through'
    }
  }, fmtZl(product.sellPrice))), /*#__PURE__*/React.createElement("div", {
    className: "mute",
    style: {
      fontSize: 11,
      marginTop: 2
    }
  }, product.unit, " \xB7 ", product.unitsPerPackage, " szt. \xB7 ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: product.stock > 50 ? 'var(--margin-good)' : 'var(--margin-ok)'
    }
  }, product.stock, " na stanie")), /*#__PURE__*/React.createElement("button", {
    className: `btn ${inCart ? 'btn-secondary' : 'btn-dark'} btn-sm`,
    style: {
      marginTop: 10,
      justifyContent: 'center'
    },
    onClick: () => onAdd(product)
  }, inCart ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Icon, {
    d: ICONS.check,
    size: 14
  }), " W koszyku") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Icon, {
    d: ICONS.plus,
    size: 14
  }), " Dodaj"))));
}
function Catalog({
  cart,
  onAdd
}) {
  const [cat, setCat] = useStateP('Wszystko');
  const [q, setQ] = useStateP('');
  const cats = ['Wszystko', 'Piany', 'Silikony', 'Akryle', 'Kleje', 'Akcesoria'];
  const filtered = useMemoP(() => PRODUCTS.filter(p => (cat === 'Wszystko' || p.category === cat) && (!q || p.name.toLowerCase().includes(q.toLowerCase()) || p.sku.toLowerCase().includes(q.toLowerCase()))), [cat, q]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1440,
      margin: '0 auto',
      padding: '24px 32px',
      display: 'grid',
      gridTemplateColumns: '220px 1fr',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("aside", null, /*#__PURE__*/React.createElement("div", {
    className: "caps",
    style: {
      marginBottom: 10
    }
  }, "Kategoria"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, cats.map(c => /*#__PURE__*/React.createElement("button", {
    key: c,
    onClick: () => setCat(c),
    className: "btn btn-ghost",
    style: {
      justifyContent: 'space-between',
      fontWeight: cat === c ? 600 : 500,
      background: cat === c ? 'var(--paper)' : 'transparent',
      padding: '8px 12px',
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", null, c), /*#__PURE__*/React.createElement("span", {
    className: "mute num",
    style: {
      fontSize: 11
    }
  }, c === 'Wszystko' ? PRODUCTS.length : PRODUCTS.filter(p => p.category === c).length)))), /*#__PURE__*/React.createElement("div", {
    className: "caps",
    style: {
      marginTop: 28,
      marginBottom: 10
    }
  }, "Marka"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      fontSize: 14
    }
  }, ['Langer', 'Soudal', 'Tytan', 'Penosil'].map(b => /*#__PURE__*/React.createElement("label", {
    key: b,
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    defaultChecked: b === 'Langer' || b === 'Soudal',
    style: {
      accentColor: 'var(--ink)'
    }
  }), " ", b)))), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("div", {
    className: "row row-gap-3",
    style: {
      justifyContent: 'space-between',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 24
    }
  }, cat === 'Wszystko' ? 'Cały katalog' : cat, " ", /*#__PURE__*/React.createElement("span", {
    className: "mute",
    style: {
      fontWeight: 400
    }
  }, "\xB7 ", filtered.length, " produkt\xF3w")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "inp",
    placeholder: "Filtruj w wynikach\u2026",
    value: q,
    onChange: e => setQ(e.target.value),
    style: {
      width: 220,
      fontSize: 13
    }
  }), /*#__PURE__*/React.createElement("select", {
    className: "inp",
    style: {
      width: 180,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("option", null, "Sortuj: Polecane"), /*#__PURE__*/React.createElement("option", null, "Cena rosn\u0105co"), /*#__PURE__*/React.createElement("option", null, "Cena malej\u0105co"), /*#__PURE__*/React.createElement("option", null, "Nazwa A\u2013Z")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
      gap: 16
    }
  }, filtered.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.id,
    product: p,
    onAdd: onAdd,
    inCart: cart.some(i => i.id === p.id)
  })))));
}
Object.assign(window, {
  ProductCard,
  Catalog,
  CatPlaceholder
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/customer/Catalog.jsx", error: String((e && e.message) || e) }); }

// ui_kits/customer/Shared.jsx
try { (() => {
// Shared header/nav/icons for the customer kit
const {
  useState
} = React;
const Icon = ({
  d,
  size = 20,
  stroke = 1.5,
  fill = 'none'
}) => /*#__PURE__*/React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: fill,
  stroke: "currentColor",
  strokeWidth: stroke,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  dangerouslySetInnerHTML: {
    __html: d
  }
});

// Lucide paths
const ICONS = {
  cart: '<circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  package: '<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="M3.3 7 12 12l8.7-5"/><path d="M12 22V12"/>',
  history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  minus: '<path d="M5 12h14"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  arrowRight: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  trending: '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>'
};
function Header({
  view,
  setView,
  cartCount
}) {
  const tabs = [{
    id: 'catalog',
    label: 'Katalog'
  }, {
    id: 'orders',
    label: 'Moje zamówienia'
  }, {
    id: 'account',
    label: 'Konto'
  }];
  return /*#__PURE__*/React.createElement("header", {
    className: "header",
    style: {
      borderBottom: '1px solid var(--border-1)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    className: "lang-wordmark",
    href: "#",
    onClick: e => {
      e.preventDefault();
      setView('catalog');
    }
  }, "LANGER", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--graphite-500)',
      letterSpacing: '0.18em',
      fontStyle: 'normal',
      fontWeight: 600,
      marginLeft: 6
    }
  }, "DYSTRYBUCJA")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 32,
      display: 'flex',
      gap: 4
    }
  }, tabs.map(t => /*#__PURE__*/React.createElement("a", {
    key: t.id,
    href: "#",
    onClick: e => {
      e.preventDefault();
      setView(t.id);
    },
    className: `nav-link ${view === t.id ? 'active' : ''}`
  }, t.label))), /*#__PURE__*/React.createElement("div", {
    className: "header-spacer"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: 280
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      color: 'var(--fg-3)',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    d: ICONS.search,
    size: 16
  })), /*#__PURE__*/React.createElement("input", {
    className: "inp",
    placeholder: "Szukaj po nazwie, SKU, marce\u2026",
    style: {
      paddingLeft: 32,
      fontSize: 13
    }
  })), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost btn-sm",
    onClick: () => setView('cart'),
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    d: ICONS.cart,
    size: 18
  }), " Koszyk", cartCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -4,
      right: -4,
      background: 'var(--amber-500)',
      color: 'var(--ink)',
      fontSize: 10,
      fontWeight: 700,
      padding: '2px 6px',
      borderRadius: 999,
      minWidth: 16,
      textAlign: 'center'
    }
  }, cartCount)), /*#__PURE__*/React.createElement("div", {
    className: "row row-gap-2",
    style: {
      paddingLeft: 12,
      borderLeft: '1px solid var(--border-1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 999,
      background: 'var(--graphite-900)',
      color: 'var(--white)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 12,
      fontWeight: 600
    }
  }, "MB"), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, "Budmax sp. z o.o."), /*#__PURE__*/React.createElement("div", {
    className: "tier gold",
    style: {
      padding: '1px 6px',
      fontSize: 9
    }
  }, "Z\u0142oto"))));
}
window.Icon = Icon;
window.ICONS = ICONS;
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/customer/Shared.jsx", error: String((e && e.message) || e) }); }

// ui_kits/customer/data.jsx
try { (() => {
// Seed data used across customer-kit screens
const CUSTOMER = {
  companyName: 'Budmax sp. z o.o.',
  nip: '123-456-78-90',
  tier: 'GOLD',
  tierDiscount: 2,
  yearlyTurnover: 138420
};
const SETTINGS = {
  minMargin: 17,
  targetMargin: 20,
  maxDiscount: 15
};
const PRODUCTS = [{
  id: 'p1',
  sku: 'SOU-CL-750',
  name: 'Soudal Classic 750 ml',
  brand: 'Soudal',
  category: 'Piany',
  role: 'MAGNET',
  sellPrice: 20.99,
  purchasePrice: 17.73,
  stock: 240,
  unit: 'karton',
  unitsPerPackage: 12,
  tone: '#F5F4F0'
}, {
  id: 'p2',
  sku: 'LAN-70-750',
  name: 'Langer 70 750 ml',
  brand: 'Langer',
  category: 'Piany',
  role: 'MARGIN',
  sellPrice: 19.99,
  purchasePrice: 14.50,
  stock: 180,
  unit: 'karton',
  unitsPerPackage: 12,
  tone: '#FDF6E3',
  featured: true
}, {
  id: 'p3',
  sku: 'TYT-O2-750',
  name: 'Tytan O2 750 ml',
  brand: 'Tytan',
  category: 'Piany',
  role: 'NEUTRAL',
  sellPrice: 22.50,
  purchasePrice: 18.00,
  stock: 96,
  unit: 'karton',
  unitsPerPackage: 12,
  tone: '#F0F1F3'
}, {
  id: 'p4',
  sku: 'PEN-GOLD-750',
  name: 'Penosil Gold 750 ml',
  brand: 'Penosil',
  category: 'Piany',
  role: 'NEUTRAL',
  sellPrice: 21.80,
  purchasePrice: 17.20,
  stock: 72,
  unit: 'karton',
  unitsPerPackage: 12,
  tone: '#F0F1F3'
}, {
  id: 'p5',
  sku: 'SOU-SIL-280',
  name: 'Soudal Silirub 2 280 ml',
  brand: 'Soudal',
  category: 'Silikony',
  role: 'MAGNET',
  sellPrice: 14.50,
  purchasePrice: 12.80,
  stock: 312,
  unit: 'karton',
  unitsPerPackage: 25,
  tone: '#F5F4F0'
}, {
  id: 'p6',
  sku: 'LAN-SAN-280',
  name: 'Langer Sanitary 280 ml',
  brand: 'Langer',
  category: 'Silikony',
  role: 'MARGIN',
  sellPrice: 11.80,
  purchasePrice: 7.20,
  stock: 210,
  unit: 'karton',
  unitsPerPackage: 25,
  tone: '#FDF6E3',
  featured: true
}, {
  id: 'p7',
  sku: 'LAN-AKR-300',
  name: 'Langer Akryl 300 ml',
  brand: 'Langer',
  category: 'Akryle',
  role: 'MARGIN',
  sellPrice: 6.80,
  purchasePrice: 3.90,
  stock: 420,
  unit: 'karton',
  unitsPerPackage: 25,
  tone: '#FDF6E3'
}, {
  id: 'p8',
  sku: 'SOU-FA-310',
  name: 'Soudal Fix All 310 ml',
  brand: 'Soudal',
  category: 'Kleje',
  role: 'MAGNET',
  sellPrice: 28.40,
  purchasePrice: 24.10,
  stock: 48,
  unit: 'karton',
  unitsPerPackage: 12,
  tone: '#F5F4F0'
}, {
  id: 'p9',
  sku: 'LAN-MS-290',
  name: 'Langer MS Poly 290 ml',
  brand: 'Langer',
  category: 'Kleje',
  role: 'MARGIN',
  sellPrice: 22.90,
  purchasePrice: 14.80,
  stock: 120,
  unit: 'karton',
  unitsPerPackage: 12,
  tone: '#FDF6E3'
}, {
  id: 'p10',
  sku: 'LAN-PIS-PRO',
  name: 'Pistolet Langer Pro',
  brand: 'Langer',
  category: 'Akcesoria',
  role: 'PREMIUM',
  sellPrice: 120.00,
  purchasePrice: 62.00,
  stock: 36,
  unit: 'sztuka',
  unitsPerPackage: 1,
  tone: '#FDF6E3'
}];
const CATEGORY_ICON = {
  'Piany': '../../assets/category-icons/piany.svg',
  'Silikony': '../../assets/category-icons/silikony.svg',
  'Akryle': '../../assets/category-icons/akryle.svg',
  'Kleje': '../../assets/category-icons/kleje.svg',
  'Akcesoria': '../../assets/category-icons/akcesoria.svg'
};
const ORDERS_SEED = [{
  id: 'o1',
  number: '2026/00041',
  date: '22.04.2026',
  total: 3840.20,
  status: 'DELIVERED',
  items: 7
}, {
  id: 'o2',
  number: '2026/00038',
  date: '14.04.2026',
  total: 5280.00,
  status: 'SHIPPED',
  items: 12
}, {
  id: 'o3',
  number: '2026/00031',
  date: '02.04.2026',
  total: 1928.40,
  status: 'DELIVERED',
  items: 4
}, {
  id: 'o4',
  number: '2026/00024',
  date: '21.03.2026',
  total: 7102.80,
  status: 'CONFIRMED',
  items: 15
}];
const fmtZl = n => n.toLocaleString('pl-PL', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
}) + ' zł';
const fmtNum = n => Math.round(n).toLocaleString('pl-PL');
Object.assign(window, {
  CUSTOMER,
  SETTINGS,
  PRODUCTS,
  CATEGORY_ICON,
  ORDERS_SEED,
  fmtZl,
  fmtNum
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/customer/data.jsx", error: String((e && e.message) || e) }); }

})();
