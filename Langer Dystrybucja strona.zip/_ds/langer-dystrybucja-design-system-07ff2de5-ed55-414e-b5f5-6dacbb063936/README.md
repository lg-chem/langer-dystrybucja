# Langer Dystrybucja — Design System

A B2B e-commerce platform for a Polish building-chemistry wholesaler (piany montażowe, silikony, akryle, kleje). The platform replaces manual sales-rep negotiations with a real-time pricing engine that rewards mixed-margin carts.

## What Langer sells

Building chemistry consumables, sold in cartons/palettes to trade customers:

- **Piany montażowe** (mounting foams) — Soudal, Tytan, Penosil, plus house brand Langer
- **Silikony** (silicones) — sanitary, universal, construction
- **Akryle** (acrylics) — paintable fillers
- **Kleje** (adhesives) — montażowe, hybrydowe, polyurethane
- **Akcesoria** — pistolety do pian, czyściki, taśmy

## Who uses it

- **Klient B2B** (wholesale customer) — owner/buyer at a hardware store, point of sale, renovation supply shop. Orders in cartons. Cares about price, margin on resale, speed, and stock. Signed into a closed account, doesn't see public pricing. Tiers: Standard → Silver → Gold → Platinum.
- **Admin / handlowiec** (sales rep / back-office) — manages catalog, imports from Excel, sets matching rules, watches margin and stock.

## The big idea (kluczowa logika biznesowa)

Products have **roles**:
- **MAGNET** — low margin, high demand (e.g. Soudal Classic foam). Draws customers in.
- **MARGIN** — high margin, lesser-known brands (house brand Langer, niche silicones). Pays the bills.
- **NEUTRAL** — standard.
- **PREMIUM** — very high margin, low volume.

When a customer adds a MAGNET to their cart, the system computes **"add X to save Y"** suggestions: pair with a MARGIN product to keep cart average margin above the minimum (default 17%), and in exchange offer a discount on the magnet. This is the whole product in one sentence — an automated "dobierz i zaoszczędzisz" mechanic.

The cart shows something like:

> 💡 Dobierz 2 kartony Langer 70 — Soudal Classic spadnie z 20,99 zł na 19,92 zł. Zyskujesz 12,84 zł.

## Sources given

- Technical spec for the Next.js prototype (pasted in chat): data model (Prisma), pricing algorithm, screen inventory, import flow, seed guidance.
- **No existing codebase, Figma, logo, screenshots, or brand assets** were provided. The visual system in this document is a proposed direction — the logo, color anchor, and icon choices are an opinionated starting point that the user should review and revise.

## Index — what's in this folder

| Path | What |
|---|---|
| `README.md` | this file — brand context, content fundamentals, visual foundations, iconography |
| `colors_and_type.css` | CSS variables for colors + type; semantic tokens (`--fg-1`, `--bg-surface`, `--h1`, etc) |
| `fonts/` | webfonts (Inter Tight for UI, JetBrains Mono for numerics/SKUs) |
| `assets/` | logo lockups, product-category icons, placeholder product shots |
| `preview/` | small swatch/specimen cards that render in the Design System tab |
| `ui_kits/customer/` | Customer-zone UI kit — product catalog, cart with suggestions, order flow |
| `ui_kits/admin/` | Admin UI kit — dashboard, product import, rules editor |
| `SKILL.md` | Claude Code / Agent Skills front-matter so this folder can be loaded as a skill |

## Content fundamentals

The interface language is **Polish**. Tone is that of a seasoned trade counter:

- **Rzeczowy, konkretny, bez lania wody.** No marketing fluff. "Dodaj do koszyka", not "Spraw, aby Twój koszyk był jeszcze lepszy".
- **Formalność per-Pan/Pani w komunikatach transakcyjnych** (emails, invoices, terms). In-app UI uses **imperative verb** form ("Złóż zamówienie", "Importuj plik", "Zapisz zmiany") which is neutral in Polish — neither formal nor casual.
- **"Ty" forma w podpowiedziach i mikrokopii** ("Zyskujesz 12,84 zł", "Zamów jeszcze za 12 000 zł, aby awansować na Złoto") — because the tier/savings system is motivational and personal.
- **Numbers are the content.** Prices, margin %, stock counts, carton counts. Typography must make them scannable. Always `zł` (not `PLN`), always comma decimal separator (`20,99 zł`), always space as thousands separator (`12 000 zł`).
- **Units are explicit.** "1 karton (12 szt.)", "24 szt.", "1 paleta". Never bare quantities.
- **Sentence case** everywhere, including buttons and table headers. `Złóż zamówienie` not `ZŁÓŻ ZAMÓWIENIE` or `Złóż Zamówienie`. Uppercase is reserved for the logo wordmark, status badges (`W REALIZACJI`), and short label codes (`NIP`, `SKU`).
- **No emoji in production UI.** One exception: the 💡 bulb in suggestion cards is part of the product's personality ("podpowiedź handlowca"). Used exactly once per card, at the start.
- **Polish-specific details:** NIP formatting (`123-456-78-90`), diacritics in all labels (`Marża`, `Złóż`, `Ulubione`), `zł` not `PLN`, `szt.` not `pcs`.

**Example microcopy that captures the tone:**

> **Dobrze złożony koszyk**
> Marża 18,4% — powyżej progu 17%. Zatwierdź albo dobierz jeszcze coś, by zejść z ceną.

> **Nie tak szybko**
> Marża koszyka spadłaby do 14%. Dobierz 2 kartony marki Langer albo zmniejsz rabat.

## Visual foundations

### Anchor

The brand is industrial-trade, not tech-startup. Reference points: **Würth catalogs, Leroy Merlin Pro, Knauf documentation, Polish budowlanka signage, safety-yellow site tape**. Sturdy, high-contrast, slightly utilitarian. Not playful, not glassy, not gradient-heavy.

### Color

Two-temperature palette:

- **Langer Amber `#E8A317`** — primary accent, used sparingly. Construction-tape yellow, tuned warmer to read as a brand color not a warning. Used on primary buttons, key data points, brand mark.
- **Graphite `#1C1F24` → `#6C727B` → `#E6E8EB`** — the whole neutral workspace. Text, tables, borders, surfaces. Pure black is avoided; `#1C1F24` reads as industrial steel.
- **Ink `#0B0D10`** — on the logo and on emphatic display type only.
- **Semantic margin signal colors** — these are the other thing the user sees:
  - `--margin-good` **`#2F7A4A`** (forest green) — cart margin ≥ target
  - `--margin-ok` **`#B07A0A`** (ochre) — between min and target
  - `--margin-bad` **`#B0361C`** (brick red) — below minimum
  - These three are pulled from industrial signage palettes, not web-standard success/warning/error. Muted, dignified, not dopamine-candy.
- **Tier accents** — Silver `#9AA3AD`, Gold `#C89B2E`, Platinum `#4A5563`. Used only in tier badges and the account screen.

No blue anywhere. No purple. No gradient backgrounds. No neon.

### Backgrounds & surfaces

- Page: `--bg-canvas` `#F5F4F0` — warm-tinted paper, not pure white. Matches trade-catalog feel.
- Surfaces (cards, tables): `--bg-surface` `#FFFFFF` with a 1px `#E6E8EB` border. No shadow on resting surfaces.
- Elevated surfaces (modals, popovers): white with a long, soft shadow `0 12px 32px -8px rgb(28 31 36 / 0.12)`.
- No glassmorphism, no backdrop blur. One exception: the sticky cart summary has a 90% opaque background over a very subtle 8px blur so content scrolls readably beneath.

### Typography

Two-family system:

- **Inter Tight** for all UI text, headings, tables, buttons. Weights 400, 500, 600, 700. Tight tracking at display sizes (`letter-spacing: -0.02em`).
- **JetBrains Mono** for SKUs, NIPs, order numbers, prices in tables, and anywhere a number should align column-to-column. Weights 400, 500, 600.

Typographic scale (px @ 16 base):
- Display 48 / 1.05
- H1 32 / 1.15
- H2 24 / 1.2
- H3 20 / 1.3
- Body 15 / 1.5
- Small 13 / 1.4
- Caption 11 / 1.3 uppercase tracked +0.06em (used for table headers, tier labels, `NETTO` micro-labels)

**Both fonts are on Google Fonts.** We load them via `@font-face` pointing at `fonts/` if local files are present, otherwise from Google Fonts CDN. **Flag for the user:** no logotype font was specified — we're using Inter Tight 700 italic with tight negative tracking as the wordmark. If Langer has a proper logotype, please supply.

### Spacing

4px grid. Tokens: `--space-1` 4px → `--space-2` 8px → `--space-3` 12px → `--space-4` 16px → `--space-5` 24px → `--space-6` 32px → `--space-7` 48px → `--space-8` 64px. Tables are dense: 12px vertical cell padding, 16px horizontal. Cards are roomy: 24px interior padding.

### Corner radii

Restrained — this is not rounded-everything SaaS.
- `--radius-sm` 4px — inputs, buttons, tags
- `--radius-md` 6px — cards, modals
- `--radius-lg` 10px — top-level panels, product images
- `--radius-full` 999px — only on avatar, tier badge medallion

### Borders

Visible, 1px, `#E6E8EB` for resting dividers, `#D1D5DA` for emphasis, `#1C1F24` for focused inputs. Borders do a lot of heavy lifting here — surfaces are defined by lines, not by shadows.

### Shadows

Three elevations only:

- **E0** — none (resting surfaces)
- **E1** — `0 1px 2px rgb(28 31 36 / 0.06), 0 1px 1px rgb(28 31 36 / 0.04)` (hover on cards)
- **E2** — `0 12px 32px -8px rgb(28 31 36 / 0.12), 0 4px 8px -4px rgb(28 31 36 / 0.06)` (modals, popovers, sticky cart)

No inner shadows. No colored shadows.

### States

- **Hover** on interactive surfaces: background darkens to `#F5F4F0` (canvas tone pulled up over white) and border strengthens. On amber buttons, amber darkens to `#C78A0E`.
- **Press** (`:active`): 1px translateY(1px), no scale transform. Tactile but understated. Amber button darkens further to `#A97509`.
- **Focus**: 2px solid `--ink` outline with 2px offset. No glowing ring.
- **Disabled**: opacity 0.4, cursor not-allowed, no other color shift.
- **Loading**: skeleton blocks in `#EEEDE8` with 1.5s pulse, never a spinner on data (spinners only for file imports and form submits).

### Motion

Sober and short.
- 120ms for state changes (hover, press)
- 180ms for small layout (add to cart, remove row)
- 240ms for larger panel entrances
- Easing: `cubic-bezier(0.2, 0, 0, 1)` (standard decel) for most things, `cubic-bezier(0.3, 0, 0.2, 1)` for sheet slide-ups
- **One delighter:** the margin gauge in the cart animates the numeric value when it changes — a 400ms count-up/count-down — because it's the core product feedback.

### Layout

- Max content width: 1440px, gutters 32px desktop / 16px mobile.
- Admin uses a left sidebar (240px, collapsible to 64px icon rail). Customer zone uses a top bar + full-width content.
- Sticky elements: top header (64px), admin sidebar, cart summary rail on `/cart` (320px wide, sticks to viewport on desktop, becomes a bottom sheet on mobile).
- Tables are the workhorse. Zebra striping is **off by default** — rely on row borders. Sticky first column on wide tables. Numeric columns right-aligned, monospace.

### Transparency & blur

Avoided except the sticky cart summary (see above) and hover-dim on row actions (80% opacity). No frosted-glass modals, no translucent sidebars.

### Iconography direction

Single line-icon set — **Lucide** (1.5px stroke, rounded caps). See ICONOGRAPHY section below.

### What good looks like

A screen should feel like a well-printed trade catalog on a screen: dense, legible, quietly authoritative. If it looks like a B2C e-commerce site, we failed. If it looks like a SaaS dashboard with rainbow charts, we failed. If it looks like a spreadsheet that someone gave a little bit of love, we're close.

## Iconography

**Library: Lucide Icons** (MIT, free). Loaded from CDN in UI kits (`https://unpkg.com/lucide-static@latest/icons/`). 1.5px stroke, 24px default, 20px in dense contexts (table rows, buttons), 16px in inline text.

**Why Lucide:** Closest match to the industrial/utility feel we want. Heroicons stroke variant reads too soft; Feather is too thin at trade-data densities; Material icons are too filled/decorative. Phosphor was a close second but Lucide's rounded-cap line weight is more forgiving against a `#F5F4F0` canvas.

**Rules:**
- Always inherit `currentColor`. Never hard-code icon colors.
- Never combine line and filled icons in the same UI. All line, or all filled. This system is all line.
- **No emoji in production UI**, with the single exception of 💡 at the start of a suggestion card ("podpowiedź handlowca" microinteraction).
- Product categories get dedicated SVG mini-icons we've drawn in-house (spray-can for piany, tube for silikony, bucket for kleje) — stored in `assets/category-icons/`.
- The brand logo is a simple wordmark + filled square mark — see `assets/logo/`.

**Substitution flag for the user:**
- We don't have Langer's real logo. We drew a wordmark as a proposed placeholder (amber square + "LANGER" in Inter Tight 700). Please replace with the real mark when you have it.
- We don't have real product photography. Catalog cards use colored placeholder tiles with the category icon + SKU. Please supply real product shots.

## Next steps for the user

This design system is a **proposed direction built from the spec alone**. To get to production-ready:

1. **Supply the real Langer logo, brand colors if different from amber, and any existing print/catalog collateral.** The amber is an opinionated guess.
2. **Send 5–10 real product photos** (one per category minimum). The placeholders are ugly on purpose.
3. **Confirm the typographic direction** (Inter Tight + JetBrains Mono). Happy to swap to a more characterful Polish-designed face like the commercial "FF Real" or free alternative "Sora" if the budget allows.
4. **Review the Polish microcopy examples** in the UI kits — tweak to match your actual sales voice.
